﻿using System;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;

namespace Sbornik_2_ISP_5
{
    class Program
    {
        static void Main()
        {
            try
            {
                Text3();
            }
            catch (Exception)
            {
                Console.WriteLine("Случилась ошибка, рестарт программы");
                Console.ReadKey();
                Console.Clear();
                Main();
            }
        }
        public static void Begin3()
        {
            int a = 6;
            int b = 7;
            Console.WriteLine($"a = {a}, b = {b}\nПлощадь = {a * b}\nПериметр = {2 * (a * b)}");
        } //1
        public static void Begin28()
        {
            int a = 2;
            int temp = a * a;
            int temp2 = temp * a;
            Console.WriteLine($"A = {a}");
            Console.WriteLine($"A^2 = {temp}");
            Console.WriteLine($"A^3 = {temp2}");
            temp2 = temp2 * temp;
            Console.WriteLine($"A^5 = {temp2}");
            temp = temp2 * temp2;
            Console.WriteLine($"A^10 = {temp}");
            temp = temp * temp2;
            Console.WriteLine($"A^15 = {temp}");

        } //2 
        public static void Integer3()
        {
            double bait = 4096;
            Console.WriteLine($"Файл занимает {bait} байт или {bait / 1024} килобайт");
        } //3
        public static void Integer28()
        {
            int k = 8;
            int n = 3;
            int week = 1;
            for (int i = k; i > 7 - n; i -= 7)
                week++;
            Console.WriteLine($"k = {k}, n = {n}");
            Console.WriteLine($"День {k} принадлежит {week} неделе");
        } //4
        public static void Boolean3()
        {
            int A = 91;
            bool flag = false;
            if (A % 2 == 0)
                flag = true;
            Console.WriteLine($"{A} Четное: {flag}");
        } //5
        public static void Boolean28()
        {
            int x = 4;
            int y = 3;
            bool flag = false;
            if ((x > 0 & y > 0) | (x < 0 & y < 0))
                flag = true;
            Console.WriteLine($"Точка {x}:{y} лежит в 1 или 3 координатной четверти: {flag}");
        } //6
        public static void If3()
        {
            Random rnd = new Random();
            int number = rnd.Next(-5, 5);
            Console.WriteLine($"Число {number}");
            if (number > 0)
                number++;
            else if (number < 0)
                number -= 2;
            else if (number == 0)
                number = 10;
            Console.WriteLine(number);
        } //7
        public static void If28()
        {
            int year = 2020;
            int days = 365;
            if (year % 4 == 0)
            {
                if (year % 100 == 0 & year % 400 != 0) days = 365;
                else days++;
            }
            Console.WriteLine($"Дней {days} в {year} году");
        } //8
        public static void Case3()
        {
            int month = 6;
            Console.WriteLine($"Месяц под номером {month}");
            switch (month)
            {
                case 1:
                    Console.WriteLine("Зима");
                    break;
                case 2:
                    Console.WriteLine("Зима");
                    break;
                case 3:
                    Console.WriteLine("Весна");
                    break;
                case 4:
                    Console.WriteLine("Весна");
                    break;
                case 5:
                    Console.WriteLine("Весна");
                    break;
                case 6:
                    Console.WriteLine("Лето");
                    break;
                case 7:
                    Console.WriteLine("Лето");
                    break;
                case 8:
                    Console.WriteLine("Лето");
                    break;
                case 9:
                    Console.WriteLine("Осень");
                    break;
                case 10:
                    Console.WriteLine("Осень");
                    break;
                case 11:
                    Console.WriteLine("Осень");
                    break;
                case 12:
                    Console.WriteLine("Зима");
                    break;
            }

        } //9
        public static void For3()
        {
            int a = 2;
            int b = 10;
            int count = 0;
            Console.WriteLine($"A = {a}, B = {b}");
            for (int i = a + 1; i < b; i++)
            {
                Console.WriteLine(i);
                count++;
            }
        } //10
        public static void For28()
        {
            double x = 0.85;
            int N = 3;
            double result = 0;
            for (int i = 1; i <= N; i++)
            {
                result += (2 * i - 3) * Math.Pow(x, i) / (2 * 4 * (2 * i));
            }
            Console.WriteLine($"Выражение при x = {x}, N = {N} = {result}");
        } //11
        public static void While3()
        {
            int n = 14;
            int k = 3;
            int result = 0;
            Console.WriteLine($"N: {n} K: {k} ");
            while (n >= k)
            {
                n -= k;
                result++;
            }
            Console.WriteLine($"Результат деления: {result}, остаток: {n}");
        } //12
        public static void While28()
        {
            double e = 2.6;
            int k = 2;
            double Ak0 = 2;
            double Ak = 2 + 1 / Ak0;
            while (Math.Abs(Ak - Ak0) < e)
            {
                Ak0 = Ak;
                Ak += 2 + 1 / Ak0;
                k++;
            }
            Console.WriteLine($"Ak = {Ak}, Ak-1 = {Ak0}, k = {k}");
        } //13
        public static void Series3()
        {
            double[] mass = new double[10] { 0.4, 0.9, 2.4, 1.3, 4.2, 9.2, 1.6, 0.052, 7.3, 4.8 };
            double sum = 0;
            for (int i = 0; i < mass.Length; i++)
                sum += mass[i];
            Console.WriteLine($"Среднее арифметическое: {sum / mass.Length}");

        } //14
        public static void Series28()
        {
            int N = 10;
            double[] mass = new double[10] { 0.4, 0.9, 2.4, 1.3, 4.2, 9.2, 1.6, 0.052, 7.3, 4.8 };
            for (int i = 0; i < mass.Length; i++)
            {
                Console.WriteLine(Math.Pow(mass[i], N));
                N--;
            }
        } //15
        public static void Proc3()
        {
            int a = 5;
            int b = 7;
            int c = 9;
            int d = 4;
            Proc3_function(a, b);
            Proc3_function(a, c);
            Proc3_function(a, d);
        } //16
        public static void Proc3_function(int x, int y)
        {

            Console.WriteLine($"Среднее арифметическое: {(x + y) / 2}");
            Console.WriteLine($"Среднее геометрическое: {Math.Pow(x * y, 1 / 3)}");
        } //16 функция
        public static void Proc28()
        {
            int count = 0;
            int[] mass = new int[10] { 3, 2, 10, 12, 11, 29, 50, 70, 823848233, 83 };
            for (int i = 0; i < mass.Length; i++)
            {
                if (Proc28_function(mass[i]) == true)
                    count++;
            }
            Console.WriteLine($"Простых чисел: {count}");

        } //17
        public static bool Proc28_function(int number)
        {
            bool flag = true;
            for (int i = 2; i <= number; i++)
                if (number % i == 0 & i != number)
                {
                    flag = false;
                    break;
                }
            return flag;
        } //17 функция
        public static void Proc53()
        {
            int year = 2020;
            Console.WriteLine("Введите месяц, год 2020");
            int month = int.Parse(Console.ReadLine());
            Proc53_function(year, month);
        } //18
        public static void Proc53_function(int year, int month)
        {

            int IsVisokosni = 0;
            if (year % 4 == 0)
            {
                if (!(year % 100 == 0 & year % 400 != 0))
                    IsVisokosni++;
            }
            switch (month)
            {
                case 1:
                    Console.WriteLine("31 день");
                    break;
                case 2:
                    Console.WriteLine($"{28 + IsVisokosni} дней");
                    break;
                case 3:
                    Console.WriteLine("31 день");
                    break;
                case 4:
                    Console.WriteLine("30 дней");
                    break;
                case 5:
                    Console.WriteLine("31 день");
                    break;
                case 6:
                    Console.WriteLine("30 дней");
                    break;
                case 7:
                    Console.WriteLine("31 день");
                    break;
                case 8:
                    Console.WriteLine("31 день");
                    break;
                case 9:
                    Console.WriteLine("30 дней");
                    break;
                case 10:
                    Console.WriteLine("31 день");
                    break;
                case 11:
                    Console.WriteLine("30 дней");
                    break;
                case 12:
                    Console.WriteLine("31 день");
                    break;
            }
        } //18 функция
        public static void Minmax3()
        {
            int[] a = { 2, 4, 7, 9, 12 };
            int[] b = { 7, 5, 9, 10, 2 };
            int max = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] + b[i] > max)
                    max = a[i] + b[i];
            }
            Console.WriteLine($"Максимальный периметр {max * 2}");
        } //19
        public static void Minmax28()
        {
            int[] numbers = new int[5] { 1110, 111100, 111100, 111111, 1111110 };
            int[] counts = { 0, 0, 0, 0, 0 };
            int countMax = 0;
            string subsequence = "";
            string MaxSubsequence = "";
            for (int i = 0; i < numbers.Length; i++)
            {
                subsequence = numbers[i].ToString();
                for (int j = 0; j < subsequence.Length; j++)
                {
                    if (subsequence[j] == '1')
                    {
                        counts[i]++;
                    }
                }
            }
            for (int i = 0; i < counts.Length; i++)
                if (counts[i] >= countMax)
                {
                    MaxSubsequence = numbers[i].ToString();
                    countMax = counts[i];
                }

            if (countMax == 0)
                Console.WriteLine("00");
            else
                for (int i = counts.Length - 1; i > 0; i--)
                    if (countMax == counts[i])
                    {
                        Console.WriteLine($"Число под номером {i + 1}, число элементов {MaxSubsequence.Length}");
                        break;
                    }
        } //20
        public static void Array3()
        {
            int[] mass = new int[5];
            int A = 2;
            int D = 3;
            for (int i = 0; i < mass.Length; i++)
            {
                mass[i] = A + (i + 1) * D;
                Console.WriteLine($"{mass[i]}, A = {A}, D = {D}");
            }
        } //21
        public static void Array28()
        {
            int[] mass = { 2, 4, 1, 7, 9, 3, 5 };
            int max = int.MaxValue;
            for (int i = 0; i < mass.Length; i += 2)
            {
                if (max > mass[i])
                    max = mass[i];
            }
            Console.WriteLine(max);
        } //22
        public static void Array53()
        {
            int[] A = { 2, 4, 6, 3, 9 };
            int[] B = { 3, 2, 9, 0, 3 };
            int[] C = new int[5];
            for (int i = 0; i < A.Length; i++)
            {
                if (A[i] > B[i])
                    C[i] = A[i];
                else
                    C[i] = B[i];
            }
            foreach (int a in C)
                Console.WriteLine(a);
        } //23
        public static void Array78()
        {
            double[] mass = { 10, 13, 21, 42, 17 };
            double[] thisMass = { 10, 13, 21, 42, 17 };
            for (int i = 0; i < mass.Length; i++)
            {
                if (i == 0)
                    mass[i] = (thisMass[i] + thisMass[i + 1]) / 2;
                if (i == mass.Length - 1)
                    mass[i] = (thisMass[i] + thisMass[i - 1]) / 2;
                if (i != 0 & i != mass.Length - 1)
                    mass[i] = (thisMass[i] + thisMass[i + 1] + thisMass[i - 1]) / 3;
            }
            foreach (double a in mass) Console.WriteLine(a);
        } //24
        public static void Array103()
        {
            int[] mass = { 4, 0, 6, 2, 3, 9, 5 };
            int max = 0;
            int min = int.MaxValue;
            for (int i = 0; i < mass.Length; i++)
            {
                if (mass[i] > max)
                    max = mass[i];
                if (mass[i] < min)
                    min = mass[i];
            }
            for (int i = 0; i < mass.Length; i++)
            {

                if (mass[i] == min)
                {
                    mass[i - 1] = 0;
                    break;
                }

            }
            for (int i = 0; i < mass.Length; i++)
                if (mass[i] == max)
                    mass[i + 1] = 0;
            foreach (int a in mass) Console.WriteLine(a);
        } //25
        public static void Array128()
        {
            string[] mass = { "666", "iiiiii", "@@@@", "ll", "333333", "OOOO" };
            int max = 0;
            for (int i = 0; i < mass.Length; i++)
                if (mass[i].Length > max)
                    max = mass[i].Length;
            for (int i = 0; i < mass.Length; i++)
                if (max == mass[i].Length)
                {
                    mass[i] = mass[i] + mass[i][0];
                    break;
                }

            foreach (string a in mass) Console.WriteLine(a);
        } //26
        public static void Matrix3()
        {
            int[] mass = { 2, 3 };
            int[,] matrix = new int[2, 2];
            for (int i = 0; i < matrix.GetLength(0); i++)
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = mass[j];
                }
            for (int i = 0; i < matrix.GetLength(0); i++, Console.WriteLine())
                for (int j = 0; j < matrix.GetLength(1); j++)
                    Console.WriteLine(matrix[i, j]);
        } //27
        public static void Matrix28()
        {
            int[] columnMax = { int.MinValue, int.MinValue };
            int resultMax = 0;
            int[,] matrix = new int[2, 2] { { 3, 6 }, { 9, 5 } };
            for (int i = 0; i < matrix.GetLength(0); i++)
                for (int j = 0; j < matrix.GetLength(1); j++)
                    if (matrix[i, j] > columnMax[i])
                        columnMax[i] = matrix[i, j];
            for (int i = 0; i < columnMax.Length; i++)
                if (columnMax[i] > resultMax)
                    resultMax = columnMax[i];
            Console.WriteLine(resultMax);
        } //28
        public static void Matrix53()
        {
            bool[] isPositive = { true, true, true };
            int[] temp = { int.MaxValue, int.MaxValue, int.MaxValue };
            int[,] matrix = new int[3, 3] { { 3, 6, 7 }, { 9, 5, 4 }, { 4, -3, 6 } };
            for (int i = 0; i < matrix.GetLength(0); i++)
                for (int j = 0; j < matrix.GetLength(1); j++)
                    if (matrix[i, j] < 0)
                        isPositive[i] = false;
            for (int i = isPositive.Length - 1; i > 0; i--)
                if (isPositive[i] == true)
                    for (int j = 0; j < matrix.GetLength(1); j++)
                    {
                        temp[j] = matrix[i, j];
                        matrix[i, j] = matrix[0, j];
                        matrix[0, j] = temp[j];
                    }
            for (int i = 0; i < matrix.GetLength(0); i++, Console.WriteLine())
                for (int j = 0; j < matrix.GetLength(1); j++)
                    Console.WriteLine(matrix[i, j]);
        } //29
        public static void Matrix78()
        {
            int[,] matrix = new int[3, 3] { { 8, 6, 7 }, { 9, 5, 4, }, { 5, 6, 9 } };
            int[] stringMin = { int.MaxValue, int.MaxValue, int.MaxValue };
            int[,] temp = new int[3, 3] { { int.MaxValue, int.MaxValue, int.MaxValue }, { int.MaxValue, int.MaxValue, int.MaxValue }, { int.MaxValue, int.MaxValue, int.MaxValue } };
            for (int i = 0; i < matrix.GetLength(0); i++)
                for (int j = 0; j < matrix.GetLength(1); j++)
                    if (matrix[i, j] < 0)
                        temp[i, j] = matrix[i, j];

            for (int i = 0; i < matrix.GetLength(0); i++)
                for (int j = 0; j < matrix.GetLength(1); j++)
                    if (matrix[i, j] < stringMin[i])
                        stringMin[i] = matrix[i, j];
            Array.Sort(stringMin);
            Array.Reverse(stringMin);

            for(int z = 0; z < stringMin.Length; z++)
                for (int i = 0; i < matrix.GetLength(0); i++)
                    for (int j = 0; j < matrix.GetLength(1); j++)
                        if (matrix[i, j] == stringMin[z])
                        {
                            for (int k = 0; k < matrix.GetLength(1); k++)
                            {
                                temp[i, k] = matrix[i, k];
                                matrix[i, k] = matrix[z, k];
                                matrix[z, k] = temp[i, k];
                            }
                            break;
                        }


            for (int i = 0; i < matrix.GetLength(0); i++, Console.WriteLine())
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j] == stringMin[i])
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(matrix[i, j]);
                    }
                    else
                    { 
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine(matrix[i, j]);
                    } 
                }
            Console.ForegroundColor = ConsoleColor.White;
        } //30
        public static void String3()
        {
            Console.WriteLine($"{(char)('C' - 1)}\n{(char)('C' + 1)}");
        } //31
        public static void String28()
        {
            char symbol = 'C';
            string text = "dskfjdsjfjCmxkksCkksjjjCCjjjmCCCkkkMMZJkCk";
            for (int i = 0; i < text.Length; i++)
                if (text[i] == symbol)
                {
                    text = text.Insert(i, symbol.ToString());
                    i++;
                }
            Console.WriteLine(text);
        } //32
        public static void String53()
        {
            int count = 0;
            string text = "Дана, строка-предложение, на, русском языке. Подсчитать, количество содержащихся в строке, знаков препинания.";
            for (int i = 0; i < text.Length; i++)
                if (text[i] == ',')
                    count++;
            Console.WriteLine($"{count} запятых");
        } //33
        public static void File3()
        {
            int A = 3;
            int D = 6;
            string path = Directory.GetCurrentDirectory() + "\\Файлы\\File3\\Результат\\A3 D6.txt";
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                using(StreamWriter sw = new StreamWriter(fs))
                {
                    for(int i = 0; i <= 10; i++)
                    {
                        sw.Write($"{A + (D * i)}; ");
                    }
                }
            }
            Console.WriteLine("Запись завершена, открытие файла");
            Process.Start("notepad.exe", path);
        } //34
        public static void File28()
        {
            int[] mass = { 2, 4, 7, 8, 15, 8, 9 };
            string path = Directory.GetCurrentDirectory() + "\\Файлы\\File28\\Результат\\2 4 7 8 15 8 9.txt";
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    sw.Write($"{mass[0]}; ");
                    for (int i = 1; i < mass.Length-1; i++)
                    {
                        mass[i] = (mass[i-1]+mass[i]+mass[i+1])/3;
                        sw.Write($"{mass[i]}; ");
                    }
                    sw.Write($"{mass[mass.Length-1]}; ");
                }
            }
            Console.WriteLine("Запись завершена, открытие файла");
            Process.Start("notepad.exe", path);
        } //35
        public static void File53()
        {
            int N = 2;
            string file = string.Empty;
            string path = Directory.GetCurrentDirectory() + "\\Файлы\\File53\\Результат";
            using (FileStream fs = new FileStream($"{path}\\Файл-архив.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    file =  sr.ReadToEnd();
                    sr.Close();
                }
            }
            string[] elems = file.Split("\n");
            List<string> filesData = new List<string>();
            
            for(int i = 1; i < elems.Length; i++)
            {
                string[] temp = elems[i].Split(";");
                filesData.Add(temp[0]);
                filesData.Add(temp[1]);
            }
            using (FileStream fs = new FileStream($"{path}\\{N}.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    for (int i = 1; i <= N * 2; i += 2)
                        if(i == N*2-1)
                            sw.Write(filesData[i]);
                }
            }
            Console.WriteLine("Запись завершена, открытие файла");
            Process.Start("explorer.exe", path);
        } //36
        public static void File78()
        {
            string file = string.Empty;
            string path = Directory.GetCurrentDirectory() + "\\Файлы\\File78\\Результат";
            using (FileStream fs = new FileStream($"{path}\\Числа.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    file = sr.ReadToEnd();
                    sr.Close();
                }
            }
            string[] inputedMatrixValues = file.Split("\r\n");

            string[] elems = file.Split("|");
            string[] matrixStrings= elems[0].Split("\r\n");
            int N = int.Parse(matrixStrings[0]);

            int cyclecounter = 0;
            string[,] inputedMatrix = new string[N, matrixStrings.Length - 1];
            for (int i = 0; i < inputedMatrix.GetLength(0); i++)
                for (int j = 0; j < inputedMatrix.GetLength(1); j++)
                {
                    if (inputedMatrixValues[cyclecounter] != "|")
                    {
                        inputedMatrix[i, j] = inputedMatrixValues[cyclecounter];
                        cyclecounter++;
                    }
                    else
                    {
                        cyclecounter++;
                        j--;
                    }
                }
            string[,] matrix = new string[matrixStrings.Length-1, N];
            using (FileStream fs = new FileStream($"{path}\\Транспонированная матрица.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    for (int i = 0; i < matrix.GetLength(0); i++, sw.WriteLine("|"))
                        for (int j = 0; j < matrix.GetLength(1); j++)
                            sw.WriteLine(matrix[i, j] = inputedMatrix[j,i]);
                }
            }
            Console.WriteLine("Запись завершена, открытие файла");
            Process.Start("explorer.exe", path);
        } //37
        public static void Text3()
        {
            int N = 5;
            string path = Directory.GetCurrentDirectory() + "\\Файлы\\Text3\\Результат\\Файл.txt";
            File.Delete(path);
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    for (int i = 0; i <= N; i++)
                    {
                        for(int j = 0; j <= i; j++ )
                        {
                            sw.Write($"{(char)('A' + j)}");
                        }
                        for (int k = 0; k < N-i; k++)
                            sw.Write("*");
                        sw.WriteLine();
                    }
                }
            }
            Console.WriteLine("Запись завершена, открытие файла");
            Process.Start("notepad.exe", path);
        } //38
    }
}
